-- BLT NOW | Experimental NS Fase 2 | ALTA EXPLICITA DE CATALOGO
-- PREPARADO, NO EJECUTADO. Requiere revision/autorizacion para Aiven.
-- PRECONDICION: verificar estructura REAL de Aiven (no solo sabana 07/10/2026).
-- Este script NO otorga permisos a roles/usuarios NI configura puertas de informacion.
-- Despues de aplicarlo, autorizacion efectiva continua denegada hasta que se otorguen
-- permiso funcional y puerta de informacion con el sistema oficial de permisos.
-- Idempotencia por codigo: si existe codigo, no se modifica. Revisar colisiones antes.

START TRANSACTION;

INSERT INTO perm_agrupaciones (codigo, nombre, empresa, orden, activo)
SELECT 'EXPERIMENTAL_NS', 'Experimental NS', 'UNITED', 13, 1
WHERE NOT EXISTS (
  SELECT 1 FROM perm_agrupaciones WHERE codigo = 'EXPERIMENTAL_NS'
);

INSERT INTO perm_modulos (id_agrupacion, codigo, nombre, ruta_frontend, orden, activo)
SELECT g.id_agrupacion, v.codigo, v.nombre, v.ruta, v.orden, 1
FROM perm_agrupaciones g
CROSS JOIN (
  SELECT 'EXPERIMENTAL_NS_RESUMEN_DIA' AS codigo, 'Resumen del Dia NS' AS nombre,
         'experimental-ns-resumen-dia' AS ruta, 10 AS orden
  UNION ALL
  SELECT 'EXPERIMENTAL_NS_EQUIPOS_CRITICOS', 'Equipos Criticos NS',
         'experimental-ns-equipos-criticos', 20
  UNION ALL
  SELECT 'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO', 'Proyectos Mantenimiento NS',
         'experimental-ns-proyectos-mantenimiento', 30
) v
LEFT JOIN perm_modulos actual ON actual.codigo = v.codigo
WHERE g.codigo = 'EXPERIMENTAL_NS' AND g.empresa = 'UNITED' AND g.activo = 1
  AND actual.id_modulo IS NULL;

INSERT INTO perm_elementos (id_modulo, codigo, nombre, tipo, orden, activo)
SELECT m.id_modulo, CONCAT(m.codigo, '_ACCESO_VISUAL'), 'Acceso visual', 'VISUAL', 0, 1
FROM perm_modulos m
JOIN perm_agrupaciones g ON g.id_agrupacion = m.id_agrupacion
LEFT JOIN perm_elementos e ON e.codigo = CONCAT(m.codigo, '_ACCESO_VISUAL')
WHERE g.codigo = 'EXPERIMENTAL_NS' AND g.empresa = 'UNITED' AND g.activo = 1
  AND m.codigo IN (
    'EXPERIMENTAL_NS_RESUMEN_DIA',
    'EXPERIMENTAL_NS_EQUIPOS_CRITICOS',
    'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO'
  ) AND m.activo = 1 AND e.id_elemento IS NULL;

INSERT INTO perm_subelementos (id_elemento, codigo, nombre, orden, activo)
SELECT e.id_elemento, CONCAT(e.codigo, '_MODULO'), 'Mostrar modulo', 0, 1
FROM perm_elementos e
JOIN perm_modulos m ON m.id_modulo = e.id_modulo
JOIN perm_agrupaciones g ON g.id_agrupacion = m.id_agrupacion
LEFT JOIN perm_subelementos s ON s.codigo = CONCAT(e.codigo, '_MODULO')
WHERE g.codigo = 'EXPERIMENTAL_NS' AND g.empresa = 'UNITED' AND g.activo = 1
  AND e.codigo IN (
    'EXPERIMENTAL_NS_RESUMEN_DIA_ACCESO_VISUAL',
    'EXPERIMENTAL_NS_EQUIPOS_CRITICOS_ACCESO_VISUAL',
    'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO_ACCESO_VISUAL'
  ) AND e.activo = 1 AND s.id_subelemento IS NULL;

INSERT INTO perm_subelemento_acciones (id_subelemento, id_accion, codigo_permiso, activo)
SELECT s.id_subelemento, a.id_accion, CONCAT(s.codigo, '.ACCESO_VISUAL'), 1
FROM perm_subelementos s
JOIN perm_elementos e ON e.id_elemento = s.id_elemento
JOIN perm_modulos m ON m.id_modulo = e.id_modulo
JOIN perm_agrupaciones g ON g.id_agrupacion = m.id_agrupacion
JOIN perm_acciones a ON a.codigo = 'ACCESO_VISUAL' AND a.activo = 1
LEFT JOIN perm_subelemento_acciones sa ON sa.codigo_permiso = CONCAT(s.codigo, '.ACCESO_VISUAL')
WHERE g.codigo = 'EXPERIMENTAL_NS' AND g.empresa = 'UNITED' AND g.activo = 1
  AND s.codigo IN (
    'EXPERIMENTAL_NS_RESUMEN_DIA_ACCESO_VISUAL_MODULO',
    'EXPERIMENTAL_NS_EQUIPOS_CRITICOS_ACCESO_VISUAL_MODULO',
    'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO_ACCESO_VISUAL_MODULO'
  ) AND s.activo = 1 AND sa.id_subelemento_accion IS NULL;

-- Validar las filas en Panel de Control y ejecutar EXPLICITAMENTE la autorizacion
-- de permisos para los roles aprobados y las puertas por usuario. No se incluye
-- INSERT sobre rol_permisos ni usuarios_alcance_informacion para evitar grants accidentales.
COMMIT;
