-- BLT NOW | Experimental NS Fase 2 | SOLO LECTURA
-- Ejecutar manualmente en Aiven SOLO si se requiere inspeccion. No hace cambios.

SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('ns_portafolio_pruebas', 'ns_tickets_pruebas')
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- Se espera custeventblt_mot_det en la tabla experimental de Tickets.
SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'ns_tickets_pruebas'
  AND COLUMN_NAME = 'custeventblt_mot_det';

SELECT id_agrupacion, codigo, nombre, empresa, activo
FROM perm_agrupaciones
WHERE codigo = 'EXPERIMENTAL_NS';

SELECT id_accion, codigo, activo
FROM perm_acciones
WHERE codigo = 'ACCESO_VISUAL';

SELECT id_modulo, codigo, nombre, ruta_frontend, activo
FROM perm_modulos
WHERE codigo IN (
  'EXPERIMENTAL_NS_RESUMEN_DIA',
  'EXPERIMENTAL_NS_EQUIPOS_CRITICOS',
  'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO'
);

SELECT codigo_permiso, activo
FROM perm_subelemento_acciones
WHERE codigo_permiso IN (
  'EXPERIMENTAL_NS_RESUMEN_DIA_ACCESO_VISUAL_MODULO.ACCESO_VISUAL',
  'EXPERIMENTAL_NS_EQUIPOS_CRITICOS_ACCESO_VISUAL_MODULO.ACCESO_VISUAL',
  'EXPERIMENTAL_NS_PROYECTOS_MANTENIMIENTO_ACCESO_VISUAL_MODULO.ACCESO_VISUAL'
);

-- Las puertas individuales requieren configuracion por usuario (no otorgar globalmente).
SELECT id_agrupacion, codigo, empresa
FROM perm_agrupaciones
WHERE codigo = 'EXPERIMENTAL_NS';
